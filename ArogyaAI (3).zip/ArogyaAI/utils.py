#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
ArogyaAI - Utilities Module v2.0
Now with real-time voice recording and enhanced error handling
"""
from typing import Optional  # Add this import at the top
import os
import wave
import tempfile
import numpy as np
from gtts import gTTS
from googletrans import Translator
from langdetect import detect
import sounddevice as sd
from scipy.io.wavfile import write as write_wav
import speech_recognition as sr
from langdetect import DetectorFactory

# For consistent language detection results
DetectorFactory.seed = 0

# Speech recognition imports with fallback
try:
    import speech_recognition as sr
    import sounddevice as sd
    recognizer = sr.Recognizer()
    recognizer.dynamic_energy_threshold = True  # Auto-adjust for ambient noise
    recognizer.pause_threshold = 1.0  # Longer pause threshold for rural speakers
    SPEECH_RECOGNITION_AVAILABLE = True
    AUDIO_RECORDING_AVAILABLE = True
except ImportError:
    SPEECH_RECOGNITION_AVAILABLE = False
    AUDIO_RECORDING_AVAILABLE = False
    recognizer = None

# Text-to-speech imports with fallback
try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except ImportError:
    GTTS_AVAILABLE = False

# Translation imports with fallback
try:
    from googletrans import Translator
    translator = Translator()
    TRANSLATION_AVAILABLE = True
except (ImportError, AttributeError):
    TRANSLATION_AVAILABLE = False
    translator = None

# Language detection imports with fallback
try:
    from langdetect import detect
    LANGDETECT_AVAILABLE = True
except ImportError:
    LANGDETECT_AVAILABLE = False

# Enhanced language code mappings with additional parameters
LANGUAGE_MAPPINGS = {
    'en': {'stt': 'en-US', 'tts': 'en', 'min_volume': 1000},
    'hi': {'stt': 'hi-IN', 'tts': 'hi', 'min_volume': 1500},  # Higher threshold for Hindi
    'gu': {'stt': 'gu-IN', 'tts': 'gu', 'min_volume': 1500}   # Higher threshold for Gujarati
}

def record_audio(duration=5, sample_rate=16000):  # Changed to 16kHz for better voice recognition
    """Record audio directly from microphone with enhanced reliability"""
    if not AUDIO_RECORDING_AVAILABLE:
        print("Error: sounddevice module not available")
        return None
        
    try:
        print("Recording... Speak now!")
        recording = sd.rec(int(duration * sample_rate), 
                         samplerate=sample_rate, 
                         channels=1, 
                         dtype='int16')
        sd.wait()  # Wait until recording is finished
        
        # Enhanced WAV file creation with proper headers
        with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmpfile:
            write_wav(tmpfile.name, sample_rate, recording)
            return tmpfile.name
    except sd.PortAudioError as pae:
        print(f"Microphone access error: {pae}. Please check microphone permissions.")
    except Exception as e:
        print(f"Enhanced recording error: {e}")
    return None

def transcribe_audio(audio_path: str, language: str = "en") -> Optional[str]:
    """Convert speech to text using Google Speech Recognition with enhanced error handling"""
    if not SPEECH_RECOGNITION_AVAILABLE:
        print("Error: speech_recognition module not available")
        return None
        
    if not os.path.exists(audio_path):
        print(f"Error: Audio file not found at {audio_path}")
        return None

    try:
        with sr.AudioFile(audio_path) as source:
            # Enhanced ambient noise adjustment for rural environments
            recognizer.adjust_for_ambient_noise(source, duration=1)
            audio_data = recognizer.record(source)
            
        google_lang = LANGUAGE_MAPPINGS.get(language, {}).get('stt', 'en-US')
        
        try:
            # Extended timeout for rural/slow connections
            text = recognizer.recognize_google(audio_data, language=google_lang, show_all=False)
            return text
        except sr.UnknownValueError:
            print("Could not understand audio. Please speak more clearly.")
        except sr.RequestError as e:
            print(f"Network error accessing Google Speech Recognition: {e}")
        except Exception as e:
            print(f"Enhanced transcription error: {e}")
            
    except Exception as e:
        print(f"Enhanced audio processing error: {e}")
        
    return None

def text_to_speech(text: str, language: str = "en") -> Optional[str]:
    """Convert text to speech using gTTS with enhanced error handling"""
    if not GTTS_AVAILABLE:
        print("Error: gTTS module not available")
        return None
        
    if not text or not isinstance(text, str):
        print("Error: Invalid text input")
        return None

    try:
        tts_lang = LANGUAGE_MAPPINGS.get(language, {}).get('tts', 'en')
        tts = gTTS(text=text, lang=tts_lang, slow=False, lang_check=True)
        
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
                tts.save(tmp.name)
                return tmp.name
        except IOError as e:
            print(f"File system error saving audio: {e}")
        except Exception as e:
            print(f"Enhanced TTS generation error: {e}")
            
    except ValueError as ve:
        print(f"Invalid language setting: {ve}")
    except Exception as e:
        print(f"Enhanced speech generation error: {e}")
        
    return None

def detect_language(text: str) -> str:
    """Detect language of text with enhanced reliability"""
    if not LANGDETECT_AVAILABLE:
        return "en"
        
    if not text or not isinstance(text, str):
        return "en"

    try:
        lang = detect(text)
        return lang if lang in ["hi", "gu"] else "en"
    except:
        return "en"

def translate_text(text: str, target_lang: str = "en") -> str:
    """Translate text to target language with enhanced error handling"""
    if not TRANSLATION_AVAILABLE:
        return text
        
    if not text or not isinstance(text, str):
        return text

    try:
        if translator:
            result = translator.translate(text, dest=target_lang)
            return result.text if hasattr(result, 'text') else text
    except Exception as e:
        print(f"Enhanced translation error: {e}")
        
    return text

def record_and_transcribe(language="en", duration=5):
    """Record and transcribe audio in one step with enhanced reliability"""
    if not AUDIO_RECORDING_AVAILABLE or not SPEECH_RECOGNITION_AVAILABLE:
        return None
        
    try:
        audio_path = record_audio(duration=duration)
        if audio_path:
            text = transcribe_audio(audio_path, language)
            os.unlink(audio_path)  # Clean up temp file
            return text
    except Exception as e:
        print(f"Enhanced record+transcribe error: {e}")
    return None

# Enhanced test functions
if __name__ == "__main__":
    print("Testing enhanced utils module...")
    
    # Test recording and transcription
    if AUDIO_RECORDING_AVAILABLE:
        print("\nTesting enhanced voice recording... Speak after the beep")
        test_text = record_and_transcribe(duration=5)
        print(f"Transcribed text: {test_text}" if test_text else "Recording/transcription failed")
    else:
        print("\nAudio recording not available")
    
    # Test language detection
    test_hi = "मेरे सिर में दर्द है"
    print(f"\nLanguage detection for Hindi: {detect_language(test_hi)}")
    
    # Test translation
    print(f"\nTranslation to Gujarati: {translate_text('I have fever', 'gu')}")
    
    # Test TTS
    tts_file = text_to_speech("This is a health test", "en")
    print(f"\nTTS test: {'Success' if tts_file else 'Failed'}")
    
    print("\nEnhanced utils module tests complete")