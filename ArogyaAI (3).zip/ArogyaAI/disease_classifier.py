import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from utils import translate_text

# Enhanced disease database with more symptoms and conditions
DISEASE_DB = {
    "Common Cold": {
        "symptoms": ["runny nose", "sneezing", "sore throat", "cough", "mild fever", "congestion"],
        "keywords": ["cold", "sardi"],
        "advice": {
            "en": "Rest, drink warm fluids, use saline nasal drops. See doctor if fever persists beyond 3 days.",
            "hi": "आराम करें, गर्म तरल पदार्थ पिएं, नमक के पानी की बूंदें उपयोग करें। यदि बुखार 3 दिन से अधिक रहे तो डॉक्टर को दिखाएँ।",
            "gu": "આરામ કરો, ગરમ પ્રવાહી પીઓ, નમકીની ડ્રોપ્સ વાપરો. જો તાવ 3 દિવસથી વધુ રહે તો ડૉક્ટરને બતાવો."
        }
    },
    "Typhoid": {
        "symptoms": ["high fever", "headache", "stomach pain", "weakness", "constipation", "loss of appetite"],
        "keywords": ["typhoid", "typhoid fever"],
        "advice": {
            "en": "Typhoid requires antibiotics. Maintain hydration and seek immediate medical care.",
            "hi": "टाइफाइड के लिए एंटीबायोटिक्स की आवश्यकता होती है। हाइड्रेशन बनाए रखें और तुरंत चिकित्सा सहायता लें।",
            "gu": "ટાઇફોઇડ માટે એન્ટીબાયોટિક્સ જરૂરી છે. હાઇડ્રેશન જાળવો અને તરત જ ડૉક્ટરને બતાવો."
        }
    },
    "Malaria": {
        "symptoms": ["high fever", "chills", "sweating", "headache", "nausea", "body pain"],
        "keywords": ["malaria"],
        "advice": {
            "en": "Malaria is serious. Get blood test immediately and start antimalarial treatment.",
            "hi": "मलेरिया गंभीर है। तुरंत रक्त परीक्षण करवाएं और एंटीमलेरियल उपचार शुरू करें।",
            "gu": "મલેરિયા ગંભીર છે. તરત જ લોહીની તપાસ કરો અને ઉપચાર શરૂ કરો."
        }
    },
    "Pneumonia": {
        "symptoms": ["cough with phlegm", "fever", "difficulty breathing", "chest pain", "fatigue"],
        "keywords": ["pneumonia"],
        "advice": {
            "en": "Pneumonia can be dangerous. Seek emergency care if having breathing difficulties.",
            "hi": "निमोनिया खतरनाक हो सकता है। सांस लेने में तकलीफ होने पर आपातकालीन देखभाल लें।",
            "gu": "ન્યુમોનિયા ખતરનાક હોઈ શકે છે. જો શ્વાસ લેવામાં તકલીફ થાય તો તુરંત ડૉક્ટરને બતાવો."
        }
    },
    "Urinary Tract Infection": {
        "symptoms": ["burning urination", "frequent urination", "pelvic pain", "cloudy urine"],
        "keywords": ["uti", "urinary infection"],
        "advice": {
            "en": "Drink plenty of water. UTI requires antibiotics - consult doctor immediately.",
            "hi": "खूब पानी पिएं। यूटीआई के लिए एंटीबायोटिक्स की आवश्यकता होती है - तुरंत डॉक्टर से परामर्श करें।",
            "gu": "ખુબ પાણી પીઓ. યુટીઆઇ માટે એન્ટીબાયોટિક્સ જરૂરી છે - ડૉક્ટરને તરત બતાવો."
        }
    },
    "Gastroenteritis": {
        "symptoms": ["watery diarrhea", "stomach cramps", "nausea", "vomiting", "mild fever"],
        "keywords": ["stomach flu", "food poisoning"],
        "advice": {
            "en": "Drink oral rehydration solution. Eat bland foods. See doctor if symptoms persist beyond 2 days.",
            "hi": "ओरल रिहाइड्रेशन सॉल्यूशन पिएं। हल्का भोजन खाएं। यदि लक्षण 2 दिन से अधिक समय तक रहें तो डॉक्टर को दिखाएँ।",
            "gu": "ઓરલ રિહાઇડ્રેશન સોલ્યુશન પીઓ. બ્લેન્ડ ફૂડ ખાઓ. જો લક્ષણો 2 દિવસથી વધુ રહે તો ડૉક્ટરને બતાવો."
        }
    },
    "Hypertension": {
        "symptoms": ["headache", "dizziness", "blurred vision", "shortness of breath"],
        "keywords": ["high bp", "high blood pressure"],
        "advice": {
            "en": "Monitor blood pressure regularly. Reduce salt intake. Consult doctor for medication.",
            "hi": "नियमित रूप से रक्तचाप की जांच करें। नमक का सेवन कम करें। दवा के लिए डॉक्टर से परामर्श करें।",
            "gu": "રક્તચાપ નિયમિત તપાસો. મીઠું ઓછું લો. દવા માટે ડૉક્ટરની સલાહ લો."
        }
    },
    "Diabetes": {
        "symptoms": ["frequent urination", "increased thirst", "hunger", "fatigue", "blurred vision"],
        "keywords": ["sugar", "diabetes"],
        "advice": {
            "en": "Get blood sugar tested. Follow diabetic diet. Regular exercise and doctor consultation needed.",
            "hi": "ब्लड शुगर टेस्ट करवाएं। मधुमेह आहार का पालन करें। नियमित व्यायाम और डॉक्टर की सलाह आवश्यक है।",
            "gu": "બ્લડ શુગર ચેક કરાવો. ડાયાબિટીક ડાયેટ લો. નિયમિત વ્યાયામ અને ડૉક્ટરની સલાહ જરૂરી છે."
        }
    },
    "Asthma": {
        "symptoms": ["wheezing", "shortness of breath", "chest tightness", "coughing at night"],
        "keywords": ["asthma", "breathing problem"],
        "advice": {
            "en": "Use prescribed inhaler. Avoid triggers like dust/smoke. Seek emergency care for severe attacks.",
            "hi": "निर्धारित इनहेलर का उपयोग करें। धूल/धुएं जैसे ट्रिगर्स से बचें। गंभीर दौरे के लिए आपातकालीन देखभाल लें।",
            "gu": "ઇન્હેલર વાપરો. ધૂળ/ધુમાડાથી બચો. ગંભીર એટેકમાં તુરંત ડૉક્ટરને બતાવો."
        }
    },
    "Arthritis": {
        "symptoms": ["joint pain", "stiffness", "swelling", "reduced range of motion"],
        "keywords": ["joint pain", "arthritis"],
        "advice": {
            "en": "Apply warm compresses. Gentle exercise helps. Consult doctor for pain management.",
            "hi": "गर्म सिकाई करें। हल्का व्यायाम मदद करता है। दर्द प्रबंधन के लिए डॉक्टर से परामर्श करें।",
            "gu": "ગરમ સેક લો. હળવી કસરત કરો. દુખાવો માટે ડૉક્ટરની સલાહ લો."
        }
    },
    "Conjunctivitis": {
        "symptoms": ["red eyes", "itchy eyes", "watery discharge", "gritty feeling"],
        "keywords": ["eye flu", "pink eye"],
        "advice": {
            "en": "Maintain eye hygiene. Avoid rubbing eyes. Use prescribed eye drops. Highly contagious.",
            "hi": "आंखों की स्वच्छता बनाए रखें। आंखें मलने से बचें। निर्धारित आई ड्रॉप का उपयोग करें। अत्यधिक संक्रामक।",
            "gu": "આંખો સ્વચ્છ રાખો. આંખો ઘસવાથી બચો. ડૉક્ટરની સલાહ પ્રમાણે ડ્રોપ્સ વાપરો. ખૂબ ચેપી છે."
        }
    },
    "Anemia": {
        "symptoms": ["fatigue", "weakness", "pale skin", "shortness of breath", "dizziness"],
        "keywords": ["anemia", "low hemoglobin"],
        "advice": {
            "en": "Eat iron-rich foods (leafy greens, lentils). Get blood test done. May need iron supplements.",
            "hi": "आयरन युक्त भोजन (हरी पत्तेदार सब्जियां, दालें) खाएं। रक्त परीक्षण करवाएं। आयरन सप्लीमेंट की आवश्यकता हो सकती है।",
            "gu": "લોખંડવાળું ખોરાક (પાલક, દાળ) ખાઓ. લોહીની તપાસ કરાવો. આયર્ન ટેબ્લેટ જરૂરી પડી શકે."
        }
    },
    "Migraine": {
        "symptoms": ["severe headache", "nausea", "vomiting", "sensitivity to light/sound"],
        "keywords": ["migraine", "severe headache"],
        "advice": {
            "en": "Rest in dark quiet room. Stay hydrated. Identify and avoid triggers. Consult neurologist if frequent.",
            "hi": "अंधेरे शांत कमरे में आराम करें। हाइड्रेटेड रहें। ट्रिगर्स की पहचान करें और उनसे बचें। यदि बार-बार हो तो न्यूरोलॉजिस्ट से परामर्श करें।",
            "gu": "અંધારા શાંત ઓરડામાં આરામ કરો. પાણી પીઓ. ટ્રિગર ઓળખો અને ટાળો. જો વારંવાર થાય તો ન્યુરોલોજિસ્ટને બતાવો."
        }
    },
    "Tuberculosis": {
        "symptoms": ["persistent cough", "fever", "night sweats", "weight loss", "blood in cough"],
        "keywords": ["tb", "tuberculosis"],
        "advice": {
            "en": "TB is treatable but contagious. Isolate and start DOTS therapy immediately. Complete full course of medicines.",
            "hi": "टीबी उपचार योग्य है लेकिन संक्रामक है। अलग रहें और तुरंत डॉट्स थेरेपी शुरू करें। दवाओं का पूरा कोर्स पूरा करें।",
            "gu": "ટીબી સારવાર યોગ્ય છે પણ ચેપી છે. અલગ રહો અને તરત ડોટ્સ થેરપી શરૂ કરો. દવાઓનો પુરો કોર્સ પૂરો કરો."
        }
    },
    "Dengue": {
        "symptoms": ["high fever", "severe headache", "pain behind eyes", "muscle pain", "rash", "bleeding"],
        "keywords": ["dengue"],
        "advice": {
            "en": "Dengue requires medical attention. Drink plenty of fluids and go to hospital immediately.",
            "hi": "डेंगू के लिए चिकित्सा की आवश्यकता होती है। खूब सारा तरल पदार्थ पिएं और तुरंत अस्पताल जाएं।",
            "gu": "ડેન્ગી માટે તબીબી સારવાર જરૂરી છે. ખૂબ પ્રવાહી પીઓ અને તરત જ હોસ્પિટલ જાઓ."
        }
    }
}

def preprocess_text(text):
    """Enhanced text cleaning"""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
    return text

def analyze_symptoms(text, language="en"):
    # Enhanced preprocessing
    text = preprocess_text(text)
    
    # Check for direct disease mentions first
    for disease, data in DISEASE_DB.items():
        if any(keyword in text for keyword in data.get("keywords", [])):
            advice = data["advice"].get(language, data["advice"]["en"])
            diagnosis = f"Possible {disease} (keyword match)"
            return diagnosis, advice
    
    # If no direct match, proceed with symptom analysis
    symptom_texts = []
    disease_names = []
    symptom_lists = []
    
    for disease, data in DISEASE_DB.items():
        symptoms = " ".join(data["symptoms"])
        symptom_texts.append(symptoms)
        disease_names.append(disease)
        symptom_lists.append(data["symptoms"])
    
    # Create TF-IDF vectors
    vectorizer = TfidfVectorizer()
    symptom_vectors = vectorizer.fit_transform(symptom_texts)
    input_vector = vectorizer.transform([text])
    
    # Calculate similarity with each disease's symptoms
    similarities = cosine_similarity(input_vector, symptom_vectors)
    best_match_idx = similarities.argmax()
    best_match_score = similarities[0, best_match_idx]
    best_disease = disease_names[best_match_idx]
    
    # Get matched symptoms
    matched_symptoms = [symptom for symptom in symptom_lists[best_match_idx] if symptom in text]
    
    # Only return diagnosis if confidence is high enough
    if best_match_score < 0.3:  # Threshold
        diagnosis_map = {
            "en": "No clear diagnosis. Please consult a doctor.",
            "hi": "कोई स्पष्ट निदान नहीं। कृपया डॉक्टर से परामर्श करें।",
            "gu": "સ્પષ્ટ નિદાન નથી. કૃપા કરીને ડૉક્ટરની સલાહ લો."
        }
        advice_map = {
            "en": "Your symptoms are not specific enough. Please monitor and consult a doctor if symptoms persist.",
            "hi": "आपके लक्षण पर्याप्त विशिष्ट नहीं हैं। यदि लक्षण बने रहते हैं तो कृपया निगरानी करें और डॉक्टर से परामर्श करें।",
            "gu": "તમારા લક્ષણો પર્યાપ્ત ચોક્કસ નથી. જો લક્ષણો ચાલુ રહે તો કૃપા કરીને મોનિટર કરો અને ડૉક્ટરની સલાહ લો."
        }
        return diagnosis_map.get(language, diagnosis_map["en"]), advice_map.get(language, advice_map["en"])
    
    # Format diagnosis with matched symptoms
    diagnosis_map = {
        "en": f"Possible {best_disease} (matched symptoms: {', '.join(matched_symptoms)})",
        "hi": f"संभावित {best_disease} (मिलान किए गए लक्षण: {', '.join(matched_symptoms)})",
        "gu": f"શક્ય {best_disease} (મેળ ખાતા લક્ષણો: {', '.join(matched_symptoms)})"
    }
    
    diagnosis = diagnosis_map.get(language, diagnosis_map["en"])
    advice = DISEASE_DB[best_disease]["advice"].get(language, DISEASE_DB[best_disease]["advice"]["en"])
    
    return diagnosis, advice