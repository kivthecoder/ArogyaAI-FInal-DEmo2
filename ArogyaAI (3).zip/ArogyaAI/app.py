import streamlit as st
import os
import tempfile
from PIL import Image
import numpy as np
import pandas as pd
import time
from utils import (
    transcribe_audio,
    text_to_speech,
    detect_language,
    translate_text,
    record_audio  # Added the new recording function
)
from disease_classifier import analyze_symptoms
from image_classifier import classify_skin_image

# App configuration
st.set_page_config(
    page_title="ArogyaAI - Healthcare Assistant",
    page_icon="🏥",
    layout="wide"
)

# Language selection
LANGUAGES = {
    "English": "en",
    "Hindi": "hi",
    "Gujarati": "gu"
}

# Initialize session state
if 'language' not in st.session_state:
    st.session_state.language = "en"
if 'symptoms' not in st.session_state:
    st.session_state.symptoms = ""
if 'diagnosis' not in st.session_state:
    st.session_state.diagnosis = ""
if 'advice' not in st.session_state:
    st.session_state.advice = ""

# Custom CSS for rural-friendly UI
st.markdown("""
<style>
    .big-font {
        font-size:20px !important;
    }
    .big-button {
        padding: 20px !important;
        font-size: 18px !important;
    }
    .response-box {
        background-color: #f0f2f6;
        border-radius: 10px;
        padding: 20px;
        margin-top: 20px;
    }
    .recording-animation {
        display: inline-block;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background-color: red;
        margin-right: 5px;
        animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.3); opacity: 0.7; }
        100% { transform: scale(1); opacity: 1; }
    }
</style>
""", unsafe_allow_html=True)

# App header
st.title("🏥 ArogyaAI - Rural Healthcare Assistant")
st.markdown("""
<div style="text-align: center;">
    <h3>Voice and image-based healthcare for underserved communities</h3>
</div>
""", unsafe_allow_html=True)

# Language selection sidebar
with st.sidebar:
    st.header("Settings")
    selected_lang = st.selectbox(
        "Choose your language",
        list(LANGUAGES.keys()),
        index=0
    )
    st.session_state.language = LANGUAGES[selected_lang]
    
    st.markdown("---")
    st.markdown("### How to use:")
    st.markdown("1. Click microphone and describe symptoms")
    st.markdown("2. Upload skin images if needed")
    st.markdown("3. Get AI-powered health advice")
    st.markdown("4. Connect to doctor if required")

# Main app sections in tabs
tab1, tab2, tab3 = st.tabs(["Symptom Checker", "Skin Image Analysis", "Doctor Connect"])

with tab1:
    st.header("Describe Your Symptoms")
    
    input_method = st.radio(
        "Choose input method:",
        ["Voice", "Text"],
        horizontal=True
    )
    
    if input_method == "Voice":
        if st.button("🎤 Click & Speak (5 seconds)", 
                   key="record_btn",
                   use_container_width=True,
                   type="primary"):
            
            with st.spinner("Listening... Speak now!"):
                # Record audio
                audio_path = record_audio(duration=5)
                
                if audio_path:
                    # Transcribe audio
                    transcribed_text = transcribe_audio(audio_path, st.session_state.language)
                    os.unlink(audio_path)  # Clean up file
                    
                    if transcribed_text:
                        st.session_state.symptoms = transcribed_text
                        st.success("Voice input received!")
                        st.text_area("You said:", transcribed_text, height=100)
                        
                        # Auto-detect language
                        if st.session_state.language == "en":
                            detected_lang = detect_language(transcribed_text)
                            if detected_lang in ["hi", "gu"]:
                                st.session_state.language = detected_lang
                                st.info(f"Automatically detected {detected_lang} language")
                    else:
                        st.error("Could not understand audio. Please speak clearly and try again.")
    
    else:  # Text input
        st.session_state.symptoms = st.text_area(
            "Describe your symptoms",
            height=150,
            value=st.session_state.symptoms
        )
    
    # Analyze button
    if st.button("Analyze Symptoms", 
                key="analyze_btn", 
                use_container_width=True, 
                type="primary",
                disabled=not st.session_state.symptoms.strip()):
        
        if st.session_state.symptoms.strip():
            with st.spinner("Analyzing your symptoms..."):
                # Enhanced symptom cleaning
                symptoms_text = st.session_state.symptoms.lower()
                symptoms_text = ' '.join([word for word in symptoms_text.split() if len(word) > 2])
                
                # Detect language if not already set
                if st.session_state.language == "en":
                    detected_lang = detect_language(symptoms_text)
                    if detected_lang in ["hi", "gu"]:
                        st.session_state.language = detected_lang
                
                # Analyze symptoms with enhanced function
                diagnosis, advice = analyze_symptoms(symptoms_text, st.session_state.language)
                
                # Store and display results
                st.session_state.diagnosis = diagnosis
                st.session_state.advice = advice
                
                # Display results with more details
                st.markdown("### Analysis Results")
                with st.expander("Possible Condition", expanded=True):
                    st.write(diagnosis)
                    if "matched symptoms" in diagnosis.lower():
                        st.write("**Confidence:** High")
                
                with st.expander("Recommended Action", expanded=True):
                    st.write(advice)
                
                # Convert to speech
                audio_file = text_to_speech(f"{diagnosis}. {advice}", st.session_state.language)
                st.audio(audio_file, format="audio/mp3")
                
                # Store in history
                if "history" not in st.session_state:
                    st.session_state.history = []
                st.session_state.history.append({
                    "symptoms": st.session_state.symptoms,
                    "diagnosis": diagnosis,
                    "advice": advice,
                    "timestamp": pd.Timestamp.now()
                })
        else:
            st.warning("Please describe your symptoms first")

with tab2:
    st.header("Skin Image Analysis")
    st.markdown("Upload an image of skin condition (rash, wound, etc.)")
    
    uploaded_file = st.file_uploader(
        "Choose an image...",
        type=["jpg", "jpeg", "png"],
        accept_multiple_files=False
    )
    
    if uploaded_file is not None:
        image = Image.open(uploaded_file)
        st.image(image, caption="Uploaded Image", use_column_width=True)
        
        if st.button("Analyze Image", 
                    key="analyze_img_btn", 
                    use_container_width=True, 
                    type="primary"):
            
            with st.spinner("Analyzing skin condition..."):
                # Convert image to numpy array
                img_array = np.array(image)
                
                # Classify image
                prediction, confidence = classify_skin_image(img_array)
                
                # Display results
                st.markdown("### Image Analysis Results")
                st.write(f"**Condition:** {prediction}")
                st.write(f"**Confidence:** {confidence:.1f}%")
                
                # Provide advice based on prediction
                advice_map = {
                    "Infection": "This appears to be an infection. Keep the area clean and consult a doctor for antibiotics if needed.",
                    "Allergy": "This appears to be an allergic reaction. Avoid scratching and consider antihistamines after consulting a doctor.",
                    "Wound": "This appears to be a wound. Clean with antiseptic and keep covered. Seek medical help if deep or shows signs of infection.",
                    "Unknown": "The condition is unclear. Please consult a doctor for proper diagnosis."
                }
                
                advice = advice_map.get(prediction, advice_map["Unknown"])
                st.write("**Recommendation:**", advice)
                
                # Convert to speech
                audio_file = text_to_speech(
                    f"The image shows {prediction.lower()}. {advice}",
                    st.session_state.language
                )
                st.audio(audio_file, format="audio/mp3")

with tab3:
    st.header("Connect with a Doctor")
    st.markdown("""
    <div class="response-box">
        <p class="big-font">If your condition is serious or you need professional advice, 
        you can connect with a doctor for teleconsultation.</p>
    </div>
    """, unsafe_allow_html=True)
    
    if st.session_state.get('diagnosis'):
        st.markdown("### Your Current Symptoms Summary")
        st.write(f"**Symptoms:** {st.session_state.symptoms}")
        st.write(f"**Possible Condition:** {st.session_state.diagnosis}")
        st.write(f"**Advice:** {st.session_state.advice}")
    
    # Doctor connection form
    with st.form("doctor_connect"):
        st.write("Please provide your contact details:")
        name = st.text_input("Full Name", placeholder="Enter your full name")
        phone = st.text_input("Phone Number", placeholder="10 digit mobile number")
        location = st.text_input("Village/Town", placeholder="Your location")
        additional_info = st.text_area("Additional information", 
                                    placeholder="Any other details for the doctor")
        
        submitted = st.form_submit_button("Request Doctor Consultation", 
                                        type="primary",
                                        use_container_width=True)
        
        if submitted:
            if name and phone:
                # Simulate sending to doctor
                st.success("Your request has been submitted! A doctor will contact you shortly.")
                
                # Store consultation
                consultation = {
                    "name": name,
                    "phone": phone,
                    "location": location,
                    "symptoms": st.session_state.get('symptoms', ''),
                    "diagnosis": st.session_state.get('diagnosis', ''),
                    "timestamp": pd.Timestamp.now(),
                    "status": "pending"
                }
                
                if "consultations" not in st.session_state:
                    st.session_state.consultations = []
                st.session_state.consultations.append(consultation)
                
                # Show confirmation
                st.markdown(f"""
                <div class="response-box">
                    <p class="big-font">✅ Consultation requested!</p>
                    <p>Doctor will call you on {phone} within 24 hours.</p>
                    <p>For emergencies, visit nearest health center.</p>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.error("Please provide at least your name and phone number")

# History section
if st.session_state.get('history'):
    with st.expander("View History", expanded=False):
        history_df = pd.DataFrame(st.session_state.history)
        st.dataframe(history_df)
        
        if st.button("Clear History"):
            st.session_state.history = []
            st.rerun()

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center;">
    <p>ArogyaAI - Bringing healthcare to rural India</p>
    <p>Note: This is an AI assistant and not a substitute for professional medical advice.</p>
</div>
""", unsafe_allow_html=True)