# ArogyaAI - Healthcare Assistant for Rural India

A multilingual voice and image-based healthcare assistant designed for rural and underserved communities in India.

## Features

- Voice and text symptom description in English, Hindi, and Gujarati
- AI-powered symptom analysis for common diseases
- Skin image analysis for infections, allergies, and wounds
- Doctor teleconsultation request system
- Text-to-speech responses in local languages

## Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/ArogyaAI.git
   cd ArogyaAI
   ```
